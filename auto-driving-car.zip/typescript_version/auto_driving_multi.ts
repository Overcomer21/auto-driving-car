"use strict";

export class CarColl {
    public CarId: string;
    public x: number;
    public y: number;
    public direction: string;
    public fieldWidth2: number;
    public fieldHeight2: number;
    static DIRECTIONS = ["N", "E", "S", "W"];

    constructor(CarId: string, x: number, y: number, direction: string, fieldWidth: number, fieldHeight: number) {
        this.CarId = CarId;
        this.x = x;
        this.y = y;
        this.direction = direction;
        this.fieldWidth2 = fieldWidth;
        this.fieldHeight2 = fieldHeight;
    }

    private rotateLeft(): void {
        let index = CarColl.DIRECTIONS.indexOf(this.direction);
        this.direction = CarColl.DIRECTIONS[(index + 3) % 4]; // Left turn (-1)
    }

    private rotateRight(): void {
        let index = CarColl.DIRECTIONS.indexOf(this.direction);
        this.direction = CarColl.DIRECTIONS[(index + 1) % 4]; // Right turn (+1)
    }

    private moveForward(occupiedPositions: Map<string, [number, number]>): [number, number] | null {
        let dx = 0, dy = 0;
        if (this.direction === "N") dy = 1;
        else if (this.direction === "E") dx = 1;
        else if (this.direction === "S") dy = -1;
        else if (this.direction === "W") dx = -1;

        let newX = this.x + dx, newY = this.y + dy;

        if (newX >= 0 && newX < this.fieldWidth2 && newY >= 0 && newY < this.fieldHeight2) {
            if (![...occupiedPositions.values()].some(pos => pos[0] === newX && pos[1] === newY)) {
                this.x = newX;
                this.y = newY;
                return null;
            } else {
                return [newX, newY]; //  detected
            }
        }
        return null;
    }

    public executeSingleCommand(command: string, occupiedPositions: Map<string, [number, number]>): [number, number] | null {
        if (command === "L") this.rotateLeft();
        else if (command === "R") this.rotateRight();
        else if (command === "F") {
            let collision = this.moveForward(occupiedPositions);
            if (collision) return collision;
        }

        occupiedPositions.set(this.CarId, [this.x, this.y]);
        return null;
    }

    public executeCommands(commands: string, occupiedPositions: Map<string, [number, number]>): [number, number] | null {
        for (let command of commands) {
            let collision = this.executeSingleCommand(command, occupiedPositions);
            if (collision) return collision; // if a collision is detected
        }
        return null;
    }
    

    public getPosition(): string {
        return `${this.x} ${this.y} ${this.direction}`;
    }
}

export function checkCollisions(CarColls: CarColl[], commands: Map<string, string>): string {
    let occupiedPositions = new Map<string, [number, number]>();
    CarColls.forEach(car => occupiedPositions.set(car.CarId, [car.x, car.y]));

    const maxSteps = Math.max(...Array.from(commands.values(), cmd => cmd.length));

    for (let step = 0; step < maxSteps; step++) {
 
        const newDirections = new Map<string, string>();
        const tentativePositions = new Map<string, [number, number]>(occupiedPositions);
        const moves: Array<{ car: CarColl; newX: number; newY: number }> = [];

  
        CarColls.forEach(car => {
            const command = commands.get(car.CarId)?.[step];
            let dir = car.direction;
            let x = car.x;
            let y = car.y;

       
            if (command === 'L' || command === 'R') {
                const idx = CarColl.DIRECTIONS.indexOf(dir);
                dir = command === 'L' 
                    ? CarColl.DIRECTIONS[(idx + 3) % 4] 
                    : CarColl.DIRECTIONS[(idx + 1) % 4];
            }

           
            if (command === 'F') {
                let dx = 0, dy = 0;
                if (dir === 'N') dy = 1;
                else if (dir === 'E') dx = 1;
                else if (dir === 'S') dy = -1;
                else if (dir === 'W') dx = -1;

                const newX = x + dx;
                const newY = y + dy;

                if (
                    newX >= 0 && newX < car.fieldWidth2 &&
                    newY >= 0 && newY < car.fieldHeight2
                ) {
                    moves.push({ car, newX, newY });
                }
            }

            newDirections.set(car.CarId, dir);
        });

 
        let collision: [number, number] | null = null;
        const collidingCarIds: string[] = [];

       
        moves.forEach(({ car, newX, newY }) => {
            const existingCars = [...tentativePositions.values()]
                .filter(([x, y]) => x === newX && y === newY)
                .map(pos => [...tentativePositions.entries()]
                    .find(([id, p]) => p[0] === pos[0] && p[1] === pos[1])?.[0]);

            if (existingCars && existingCars.length > 0) {
                collision = [newX, newY];
                collidingCarIds.push(car.CarId, ...existingCars.filter(id => id !== undefined));
            } else {
                tentativePositions.set(car.CarId, [newX, newY]);
            }
        });

        if (collision) {
       
            const uniqueIds = [...new Set(collidingCarIds)].sort();
            console.log(`${collidingCarIds.join(' ')}`);
            console.log(`${collision[0]} ${collision[1]}`);
            console.log(`${step + 1}`);
            return `${uniqueIds.join(' ')}\n${collision[0]} ${collision[1]}\n${step + 1}`;
        }

       
        CarColls.forEach(car => {
            const dir = newDirections.get(car.CarId)!;
            car.direction = dir;

            // Update 
            const move = moves.find(m => m.car.CarId === car.CarId);
            if (move) {
                car.x = move.newX;
                car.y = move.newY;
            }

            occupiedPositions.set(car.CarId, [car.x, car.y]);
        });
    }
    console.log("no collision");
    return "no collision";
}


// test case with collision
let fieldWidth2 = 10, fieldHeight2 = 10;

let CarColls = [
    new CarColl("A", 1, 2, "N", fieldWidth2, fieldHeight2),
    new CarColl("B", 7, 8, "W", fieldWidth2, fieldHeight2)
];
let commands2 = new Map([
    ["A", "FFRFFFFRRL"],
    ["B", "FFLFFFFFFF"]
]);

// **Run Result**
checkCollisions(CarColls, commands2);


/*let fieldWidth2 = 10, fieldHeight2 = 10;*/
let CarColls1 = [
    new CarColl("A", 1, 2, "N", fieldWidth2, fieldHeight2),
    new CarColl("B", 7, 8, "W", fieldWidth2, fieldHeight2)
];

// test case no collision
let commands3= new Map([
    ["A", "FFRFFFFRRL"],  
    ["B", "FFRFFFFFF"]   
]);

// **Run Result**
checkCollisions(CarColls1, commands3);

