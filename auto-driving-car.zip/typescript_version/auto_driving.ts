/* Name: YONGKY */


export class Car {
    private static FLOWING   = ["N", "E", "S", "W"];
    public x: number;
    public y: number;
    public direction: string;
    public fieldWidth: number;
    public fieldHeight: number;

    constructor(x: number, y: number, direction: string, fieldWidth: number, fieldHeight: number) {
        this.x = x;
        this.y = y;
        this.direction = direction;
        this.fieldWidth = fieldWidth;
        this.fieldHeight = fieldHeight;
    }

    public rotateLeft() {
        let index = Car.FLOWING  .indexOf(this.direction);
        this.direction = Car.FLOWING  [(index + 3) % 4];
    }

    public rotateRight() {
        let index = Car.FLOWING  .indexOf(this.direction);
        this.direction = Car.FLOWING  [(index + 1) % 4];
    }

    public moveForward() {
        let dx = 0, dy = 0;
        if (this.direction === "N") dy = 1;
        else if (this.direction === "E") dx = 1;
        else if (this.direction === "S") dy = -1;
        else if (this.direction === "W") dx = -1;

        let newX = this.x + dx, newY = this.y + dy;
        if (newX >= 0 && newX < this.fieldWidth && newY >= 0 && newY < this.fieldHeight) {
            this.x = newX;
            this.y = newY;
        }
    }

    public executeCommands(commands: string) {
        for (let command of commands) {
            if (command === "L") this.rotateLeft();
            else if (command === "R") this.rotateRight();
            else if (command === "F") this.moveForward();
        }
    }

    public getPosition(): string {
        return `${this.x} ${this.y} ${this.direction}`;
    }
}

let fieldWidth = 10, fieldHeight = 10;
let car = new Car(1, 2, "N", fieldWidth, fieldHeight);
let commands = "FFRFFFRRLF";
car.executeCommands(commands);

console.log("Last Position:", car.getPosition());
