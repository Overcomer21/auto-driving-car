import fs from 'fs';
import { Car } from "../auto_driving"; // Fixed import syntax 

const logFile = 'output_result_log_PART1_single.txt';
fs.writeFileSync(logFile, 'Jest Test Results for Single Car:\n', 'utf8'); // Clear previous logs

function logToFile(content: string) {
    fs.appendFileSync(logFile, content + '\n', 'utf8');
}

describe("Car Class Tests", () => {
    let car: Car; // ✅ Add type annotation
    const fieldWidth = 10, fieldHeight = 10;

    beforeEach(() => {
        car = new Car(1, 2, "N", fieldWidth, fieldHeight);
    });

    test("Initial Position", () => {
        const result = car.getPosition();
        logToFile(`Initial Position: ${result}`);
        expect(result).toBe("1 2 N");
    });

    test("Rotate Left", () => {
        car.rotateLeft();
        const result = car.getPosition();
        logToFile(`Rotate Left: ${result}`);
        expect(result).toBe("1 2 W");
    });

    test("Rotate Right", () => {
        car.rotateRight();
        const result = car.getPosition();
        logToFile(`Rotate Right: ${result}`);
        expect(result).toBe("1 2 E");
    });

    test("Move Forward", () => {
        car.moveForward();
        const result = car.getPosition();
        logToFile(`Move Forward: ${result}`);
        expect(result).toBe("1 3 N");
    });

    test("Execute Last Position", () => {
        car.executeCommands("FFRFFFRRLF");
        const result = car.getPosition();
        logToFile(`Last Position: ${result}`);
        expect(result).toBe("4 3 S"); 
    });

    test("Boundary Check - Prevent Moving Outside", () => {
        const carEdge = new Car(0, 0, "S", fieldWidth, fieldHeight);
        carEdge.moveForward();
        const result = carEdge.getPosition();
        logToFile(`Boundary Check (Should Not Move): ${result}`);
        expect(result).toBe("0 0 S");
    });
});
