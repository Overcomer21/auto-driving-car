import fs from 'fs';
import { CarColl, checkCollisions } from '../auto_driving_multi'; // Correct import

const logFile = 'output_result_log_PART2_MultiCar.txt';
fs.writeFileSync(logFile, 'Jest Test Results:\n', 'utf8'); // Clear previous logs

function logToFile(content: string) {
    fs.appendFileSync(logFile, content + '\n', 'utf8');
}

describe("Car Collision Tests", () => {
    let carA: CarColl, carB: CarColl;
    let fieldWidth = 10, fieldHeight = 10;

    beforeEach(() => {
        carA = new CarColl("A", 1, 2, "N", fieldWidth, fieldHeight);
        carB = new CarColl("B", 7, 8, "W", fieldWidth, fieldHeight);
    });

    test("Detect Collision Between Two Cars", () => {
        let commands = new Map<string, string>([
            ["A", "FFRFFFFRRL"],
            ["B", "FFLFFFFFFF"]
        ]);
        let result = checkCollisions([carA, carB], commands);
        logToFile(`Collision Test Result: ${result}`);
        expect(result).toContain("5 4");
    });

    test("No Collision Scenario", () => {
        let commands = new Map<string, string>([
            ["A", "FFRFFFFRRL"],
            ["B", "FFRFFFFFF"]
        ]);
        let result = checkCollisions([carA, carB], commands);
        logToFile(`No Collision Test Result: ${result}`);
        expect(result).toBe("no collision");
    });
});
