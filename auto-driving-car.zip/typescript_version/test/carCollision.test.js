"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const auto_driving_multi_1 = require("../auto_driving_multi"); // Correct import
const logFile = 'output_result_log_PART2_MultiCar.txt';
fs_1.default.writeFileSync(logFile, 'Jest Test Results:\n', 'utf8'); // Clear previous logs
function logToFile(content) {
    fs_1.default.appendFileSync(logFile, content + '\n', 'utf8');
}
describe("Car Collision Tests", () => {
    let carA, carB;
    let fieldWidth = 10, fieldHeight = 10;
    beforeEach(() => {
        carA = new auto_driving_multi_1.CarColl("A", 1, 2, "N", fieldWidth, fieldHeight);
        carB = new auto_driving_multi_1.CarColl("B", 7, 8, "W", fieldWidth, fieldHeight);
    });
    test("Detect Collision Between Two Cars", () => {
        let commands = new Map([
            ["A", "FFRFFFFRRL"],
            ["B", "FFLFFFFFFF"]
        ]);
        let result = (0, auto_driving_multi_1.checkCollisions)([carA, carB], commands);
        logToFile(`Collision Test Result: ${result}`);
        expect(result).toContain("5 4");
    });
    test("No Collision Scenario", () => {
        let commands = new Map([
            ["A", "FFRFFFFRRL"],
            ["B", "FFRFFFFFF"]
        ]);
        let result = (0, auto_driving_multi_1.checkCollisions)([carA, carB], commands);
        logToFile(`No Collision Test Result: ${result}`);
        expect(result).toBe("no collision");
    });
});
