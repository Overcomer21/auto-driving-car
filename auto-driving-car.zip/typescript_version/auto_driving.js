"use strict";
/* Name: YONGKY */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Car = void 0;
class Car {
    constructor(x, y, direction, fieldWidth, fieldHeight) {
        this.x = x;
        this.y = y;
        this.direction = direction;
        this.fieldWidth = fieldWidth;
        this.fieldHeight = fieldHeight;
    }
    rotateLeft() {
        let index = Car.FLOWING.indexOf(this.direction);
        this.direction = Car.FLOWING[(index + 3) % 4];
    }
    rotateRight() {
        let index = Car.FLOWING.indexOf(this.direction);
        this.direction = Car.FLOWING[(index + 1) % 4];
    }
    moveForward() {
        let dx = 0, dy = 0;
        if (this.direction === "N")
            dy = 1;
        else if (this.direction === "E")
            dx = 1;
        else if (this.direction === "S")
            dy = -1;
        else if (this.direction === "W")
            dx = -1;
        let newX = this.x + dx, newY = this.y + dy;
        if (newX >= 0 && newX < this.fieldWidth && newY >= 0 && newY < this.fieldHeight) {
            this.x = newX;
            this.y = newY;
        }
    }
    executeCommands(commands) {
        for (let command of commands) {
            if (command === "L")
                this.rotateLeft();
            else if (command === "R")
                this.rotateRight();
            else if (command === "F")
                this.moveForward();
        }
    }
    getPosition() {
        return `${this.x} ${this.y} ${this.direction}`;
    }
}
exports.Car = Car;
Car.FLOWING = ["N", "E", "S", "W"];
let fieldWidth = 10, fieldHeight = 10;
let car = new Car(1, 2, "N", fieldWidth, fieldHeight);
let commands = "FFRFFFRRLF";
car.executeCommands(commands);
console.log("Last Position:", car.getPosition());
